jQuery(document).ready(function() {
         
           jQuery('.trustedCarousel').owlCarousel({
         
             loop: false,
         
             margin: 30,
         
             dot:false,
         
             responsiveClass: true,
         
             responsive: {
         
               0: {
         
                 items: 1,
         
                 nav: true
         
               },
         
               600: {
         
                 items: 2,
         
                 nav: true
         
               },
         
               1000: {
         
                 items: 3,
         
                 nav: true,
         
               }
         
             }
         
           })
         
         
         
           jQuery('#ecommerceCarousel').owlCarousel({
         
             loop: false,
         
             margin: 0,
         
             dot:false,
         
             autoplay:true,
         
             autoplayTimeout:4000,
         
             autoplayHoverPause:true,
         
             responsiveClass: true,
         
             responsive: {
         
               0: {
         
                 items: 1,
         
                 nav: true,
         
               },
         
               600: {
         
                 items: 1,
         
                 nav: true,
         
               },
         
               1000: {
         
                 items: 1,
         
                 nav: true,
         
               }
         
             }
         
           })
         
         
         
           jQuery('.tipsCarousel').owlCarousel({
         
             loop: false,
         
             margin: 40,
         
             dot:false,
         
             autoplay:true,
         
             autoplayTimeout:4000,
         
             autoplayHoverPause:true,
         
             responsiveClass: true,
         
             responsive: {
         
               0: {
         
                 items: 1,
         
                 nav: true,
         
               },
         
               600: {
         
                 items: 1,
         
                 nav: true,
         
               },
         
               1000: {
         
                 items: 2,
         
                 nav: true,
         
               }
         
             }
         
           })
         
         
         
           jQuery('.tabs-nav a').click(function() {
         
         
         
             jQuery('.tabs-nav li').removeClass('active');
         
            jQuery(this).parent().addClass('active');
         
         
         
             let currentTab = jQuery(this).attr('href');
         
             jQuery('.tabs-content .tabsBody').hide();
         
            jQuery(currentTab).show();
         
         
         
             return false;
         
           });
         
         
         
           jQuery('#backtotop').click(function(e) {
         
             e.preventDefault();
         
            jQuery('html, body').animate({scrollTop:0}, '500');
         
           });
         
           
         
         })

         jQuery(document).ready(function () {
          jQuery('.main-header li').click(function(e) {
              jQuery('.main-header li.active').removeClass('active');
              jQuery(this).addClass('active');
              e.preventDefault();
          });
      });
         