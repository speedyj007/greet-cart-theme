<?php get_header();?>

      <section class="sectionGoodCompany bg_Theme_green py-5">
         <div class="container">
            <div class="row">
               <div class="col">
                  <h3 class="text-white mb-4 text-center">You're in <b>Good Company!</b></h3>
                  <p class="text-white mb-5 text-center">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard printing and typesetting industry. Lorem Ipsum has been the industry's standard.</p>
                  <div class="d-flex flex-wrap justify-content-center text-center text-white">
                     <div class="flex-fill points py-4 px-3 ml-0 mr-3">
                        <h4 class="my-4">300+</h4>
                        <h5 class="mb-0">Active <br> Client</h5>
                     </div>
                     <div class="flex-fill points py-4 px-3 mx-3">
                        <h4 class="my-4">500+</h4>
                        <h5 class="mb-0">Project <br> Delivered</h5>
                     </div>
                     <div class="flex-fill points py-4 px-3 mx-3">
                        <h4 class="my-4">20+</h4>
                        <h5 class="mb-0">Countries <br> Client</h5>
                     </div>
                     <div class="flex-fill points py-4 px-3 mx-3">
                        <h4 class="my-4">30+</h4>
                        <h5 class="mb-0">Team <br> Members</h5>
                     </div>
                     <div class="flex-fill points py-4 px-3 ml-3 mr-0">
                        <h4 class="my-4">80%</h4>
                        <h5 class="mb-0">Retention <br> Rate</h5>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="sectionEcommercePlatform py-5 overflow-hidden">
         <div class="bg01"></div>
         <div class="container">
            <div class="col px-0">
               <div class="owl-carousel owl-theme" id="ecommerceCarousel">
                  <div class="item">
                     <div class="row no-gutters position-relative">
                        <div class="col-md-6 mb-md-0 p-md-4">
                           <h4 class="text-white">E Commerce platform</h4>
                           <img src="<?php bloginfo('template_directory'); ?> /assets/images/ecommerce.png" class="w-100" alt="" />
                        </div>
                        <div class="col-md-6 position-static ecommerce_cardbody p-5 pl-md-0">
                           <h2 class="mt-4 mb-5 text-white">Mystere Paris</h2>
                           <p class="text-white pt-3 mb-5">Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.</p>
                           <button type="button" class="btn_Theme_white text-dark mr-4">View Case Study</button>
                           <button type="button" class="btn_Transparent_green">Visit Site</button>
                        </div>
                     </div>
                  </div>
                  <div class="item">
                     <div class="row no-gutters position-relative">
                        <div class="col-md-6 mb-md-0 p-md-4">
                           <h4 class="text-white">E Commerce platform</h4>
                           <img src="<?php bloginfo('template_directory'); ?> /assets/images/ecommerce.png" class="w-100" alt="" />
                        </div>
                        <div class="col-md-6 position-static ecommerce_cardbody p-5 pl-md-0">
                           <h2 class="mt-4 mb-5 text-white">Mystere Paris</h2>
                           <p class="text-white pt-3 mb-5">Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.</p>
                           <button type="button" class="btn_Theme_white text-dark mr-4">View Case Study</button>
                           <button type="button" class="btn_Transparent_green">Visit Site</button>
                        </div>
                     </div>
                  </div>
                  <div class="item">
                     <div class="row no-gutters position-relative">
                        <div class="col-md-6 mb-md-0 p-md-4">
                           <h4 class="text-white">E Commerce platform</h4>
                           <img src="<?php bloginfo('template_directory'); ?> /assets/images/ecommerce.png" class="w-100" alt="" />
                        </div>
                        <div class="col-md-6 position-static ecommerce_cardbody p-5 pl-md-0">
                           <h2 class="mt-4 mb-5 text-white">Mystere Paris</h2>
                           <p class="text-white pt-3 mb-5">Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.</p>
                           <button type="button" class="btn_Theme_white text-dark mr-4">View Case Study</button>
                           <button type="button" class="btn_Transparent_green">Visit Site</button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <div class="dottedDivbg py-5 w-100"></div>
      <section class="sectionEliteCompany bg_Theme_green py-5">
         <div class="container">
            <div class="d-flex">
               <div class="flex-fill text-white pr-3">
                  <h2 class="mb-5">We Developed Products that got Venture Fundings & Acquired by <br> <b>Elite Companies</b></h2>
                  <p class="mb-5">Our Developed Products Got Fundings From Facebook, Nvidia, GSV, Amazon Launchpad; Acquired By Quikr & Featured In NY Times, Usatoday, Bizjournals, Silicon India, TOI & IIFL.</p>
                  <button type="button" class="btn_Transparent_green btnLg">Talk to an Expert</button>
               </div>
               <div class="flex-fill pl-4">
                  <div class="d-flex flex-wrap">
                     <div class="col bg-white py-3 px-4 mr-4"><span class="imgCenter mr-3"><img src="<?php bloginfo('template_directory'); ?> /assets/images/plane.png" alt="" /></span> Travel & Tourism</div>
                     <div class="col bg-white py-3 px-4 ml-4"><span class="imgCenter mr-3"><img src="<?php bloginfo('template_directory'); ?> /assets/images/banking.png" alt="" /></span> Banking Sectors</div>
                     <div class="w-100 my-4"></div>
                     <div class="col bg-white py-3 px-4 mr-4"><span class="imgCenter mr-3"><img src="<?php bloginfo('template_directory'); ?> /assets/images/cart.png" alt="" /></span> Retail & E-Commerce</div>
                     <div class="col bg-white py-3 px-4 ml-4"><span class="imgCenter mr-3"><img src="<?php bloginfo('template_directory'); ?> /assets/images/cart.png" alt="" /></span> Education & E Learning</div>
                     <div class="w-100 my-4"></div>
                     <div class="col bg-white py-3 px-4 mr-4"><span class="imgCenter mr-3"><img src="<?php bloginfo('template_directory'); ?> /assets/images/education.png" alt="" /></span> Media & Entertainment</div>
                     <div class="col bg-white py-3 px-4 ml-4"><span class="imgCenter mr-3"><img src="<?php bloginfo('template_directory'); ?> /assets/images/transportation.png" alt="" /></span> Transportation</div>
                     <div class="w-100 my-4"></div>
                     <div class="col bg-white py-3 px-4 mr-4"><span class="imgCenter mr-3"><img src="<?php bloginfo('template_directory'); ?> /assets/images/health.png" alt="" /></span> Health Care</div>
                     <div class="col bg-white py-3 px-4 ml-4"><span class="imgCenter mr-3"><img src="<?php bloginfo('template_directory'); ?> /assets/images/isv.png" alt="" /></span> ISV & Product Company</div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="sectionTechnology py-5">
         <div class="container">
            <h3 class="text-dark mb-5 text-center"><b>Technology</b> we Use</h3>
            <div class="tabsWrap">
               <ul class="tabs-nav d-flex p-0">
                  <li class="active flex-fill text-center"><a href="#mobility">Mobility</a></li>
                  <li class="flex-fill text-center"><a href="#web">Web & Full Stack</a></li>
                  <li class="flex-fill text-center"><a href="#ecommerce">Ecommerce & CMS</a></li>
                  <li class="flex-fill text-center"><a href="#designing">Designing</a></li>
               </ul>
               <div class="tabs-content">
                  <div class="tabsBody" id="mobility">
                     <div class="first_ring">
                        <div class="imgCenter center rounded-circle"><img src="<?php bloginfo('template_directory'); ?> /assets/images/react.png" class="p-3" alt="" /></div>
                     </div>
                     <div class="second_ring">
                        <div class="imgCenter left rounded-circle"><img src="<?php bloginfo('template_directory'); ?> /assets/images/python.png" class="p-3" alt="" /></div>
                        <div class="imgCenter right rounded-circle"><img src="<?php bloginfo('template_directory'); ?> /assets/images/dotnet.png" class="p-3" alt="" /></div>
                     </div>
                     <div class="third_ring">
                        <div class="imgCenter left rounded-circle"><img src="<?php bloginfo('template_directory'); ?> /assets/images/php.png" class="p-3" alt="" /></div>
                        <div class="imgCenter center rounded-circle"><img src="<?php bloginfo('template_directory'); ?> /assets/images/java.png" class="p-4" alt="" /></div>
                        <div class="imgCenter right rounded-circle"><img src="<?php bloginfo('template_directory'); ?> /assets/images/angular.png" class="p-4" alt="" /></div>
                     </div>
                  </div>
                  <div class="tabsBody" id="web" class="position-relative">
                     <div class="first_ring">
                        <div class="imgCenter center rounded-circle"><img src="<?php bloginfo('template_directory'); ?> /assets/images/react.png" class="p-3" alt="" /></div>
                     </div>
                     <div class="second_ring">
                        <div class="imgCenter left rounded-circle"><img src="<?php bloginfo('template_directory'); ?> /assets/images/python.png" class="p-3" alt="" /></div>
                        <div class="imgCenter right rounded-circle"><img src="<?php bloginfo('template_directory'); ?> /assets/images/dotnet.png" class="p-3" alt="" /></div>
                     </div>
                     <div class="third_ring">
                        <div class="imgCenter left rounded-circle"><img src="<?php bloginfo('template_directory'); ?> /assets/images/php.png" class="p-3" alt="" /></div>
                        <div class="imgCenter center rounded-circle"><img src="<?php bloginfo('template_directory'); ?> /assets/images/java.png" class="p-4" alt="" /></div>
                        <div class="imgCenter right rounded-circle"><img src="<?php bloginfo('template_directory'); ?> /assets/images/angular.png" class="p-4" alt="" /></div>
                     </div>
                  </div>
                  <div class="tabsBody" id="ecommerce">
                     <h3>Third Tab</h3>
                  </div>
                  <div class="tabsBody" id="designing">
                     <h3>Fourth Tab</h3>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="sectionTrusted bg_Theme_darkcyan py-5">
         <div class="container">
            <div class="row">
               <div class="col">
                  <h3 class="text-white mb-4 text-center"><b>Trusted and Loved by the Worlds Best</b></h3>
                  <p class="text-white mb-5 text-center">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.</p>
                  <div class="owl-carousel owl-theme trustedCarousel">
                     <div class="item">
                        <div class="card text-center">
                           <div class="card-body">
                              <p class="card-text mb-5 mt-4 px-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.</p>
                              <h5 class="card-title">Card title</h5>
                              <h6 class="card-subtitle mb-2 text-muted">Card subtitle</h6>
                           </div>
                        </div>
                     </div>
                     <div class="item">
                        <div class="card text-center">
                           <div class="card-body">
                              <p class="card-text mb-5 mt-4 px-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.</p>
                              <h5 class="card-title">Card title</h5>
                              <h6 class="card-subtitle mb-2 text-muted">Card subtitle</h6>
                           </div>
                        </div>
                     </div>
                     <div class="item">
                        <div class="card text-center">
                           <div class="card-body">
                              <p class="card-text mb-5 mt-4 px-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.</p>
                              <h5 class="card-title">Card title</h5>
                              <h6 class="card-subtitle mb-2 text-muted">Card subtitle</h6>
                           </div>
                        </div>
                     </div>
                     <div class="item">
                        <div class="card text-center">
                           <div class="card-body">
                              <p class="card-text mb-5 mt-4 px-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.</p>
                              <h5 class="card-title">Card title</h5>
                              <h6 class="card-subtitle mb-2 text-muted">Card subtitle</h6>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="sectionTipsTrends py-5">
         <div class="container">
            <h3 class="text-dark mb-4 text-center"><b>Tips, trends and tons of inspiration</b></h3>
            <div class="col">
               <div class="owl-carousel owl-theme tipsCarousel">
                  <div class="item">
                     <div class="card mb-3">
                        <div class="row no-gutters px-4">
                           <div class="col-md-4 py-4">
                              <img src="<?php bloginfo('template_directory'); ?> /assets/images/tips01.png" class="card-img" alt="...">
                           </div>
                           <div class="col-md-8">
                              <div class="card-body pr-0">
                                 <h5 class="card-title">What the best way to get a website</h5>
                                 <p class="card-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                 <p class="card-text pt-3"><a href="javascript:void(0);" class="text-muted">4 Days ago 16 mins read</a></p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="item">
                     <div class="card mb-3">
                        <div class="row no-gutters px-4">
                           <div class="col-md-4 py-4">
                              <img src="<?php bloginfo('template_directory'); ?> /assets/images/tips02.png" class="card-img" alt="...">
                           </div>
                           <div class="col-md-8">
                              <div class="card-body pr-0">
                                 <h5 class="card-title">What the best way to get a website</h5>
                                 <p class="card-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                 <p class="card-text pt-3"><a href="javascript:void(0);" class="text-muted">4 Days ago 16 mins read</a></p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="item">
                     <div class="card mb-3">
                        <div class="row no-gutters px-4">
                           <div class="col-md-4 py-4">
                              <img src="<?php bloginfo('template_directory'); ?> /assets/images/tips01.png" class="card-img" alt="...">
                           </div>
                           <div class="col-md-8">
                              <div class="card-body pr-0">
                                 <h5 class="card-title">What the best way to get a website</h5>
                                 <p class="card-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                 <p class="card-text pt-3"><a href="javascript:void(0);" class="text-muted">4 Days ago 16 mins read</a></p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section class="sectionAboutGeek bg_Theme_green pt-4 pb-5 text-white">
         <div class="container">
            <div class="row">
               <div class="col-6 pr-4">
                  <h3 class="mb-4">We Hoped you'd <br> end up here.</h3>
                  <form class="pt-3">
                     <input type="text" name="" class="mb-4" placeholder="Full Name">
                     <input type="text" name="" class="mb-4" placeholder="Mobile Number">
                     <select name="Project" class="mb-4">
                        <option value="Project Type">Project Type</option>
                        <option value="Project Type 01">Project Type 01</option>
                        <option value="Project Type 02">Project Type 02</option>
                        <option value="Project Type 03">Project Type 03</option>
                     </select>
                     <textarea class="mb-4" rows="3" placeholder="Tell us About your Project"></textarea>
                     <button type="button" class="btn_Theme_white btnLg">Send it</button>
                  </form>
               </div>
               <div class="col-6">
                  <h3 class="text-white mb-3">About Cart Geek</h3>
                  <p class="mb-4">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley</p>
                  <div class="imgCenter"><img src="<?php bloginfo('template_directory'); ?> /assets/images/about-geek.png" alt="" /></div>
               </div>
            </div>
         </div>
      </section>
	  
	  <?php get_footer();?>