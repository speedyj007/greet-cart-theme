<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	      <link href="https://fonts.googleapis.com/css2?family=Muli:wght@400;700;800&display=swap" rel="stylesheet">
		
		<?php wp_head();?>
  
  
      <title>Cartgeek</title>
   </head>
   <body>
      <section class="sectionBanner">
         <div class="header py-3">
            <div class="container pl-0 pr-0">
               <nav class="navbar navbar-expand-lg navbar-light pl-0 pr-0">
                  <div class="brandLogo flex-shrink-1"><img src="<?php bloginfo('template_directory'); ?> /assets/images/logo.png" alt="" /></div>
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                     <ul class="navbar-nav mr-auto ml-auto pl-0 pr-0">
                        <li class="nav-item active">
                           <a class="nav-link" href="#">Home</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#">Who we are</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#">What we do</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#">Our Work</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#">Blog</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#">Contact</a>
                        </li>
                     </ul>
                     <form class="form-inline my-2 my-lg-0">
                        <button type="button" class="btn_Theme_green">GET IN TOUCH</button>
                     </form>
                  </div>
               </nav>
            </div>
         </div>
         <div class="banner">
            <div class="container">
               <div class="row align-items-center">
                  <div class="col-6">
                     <h1>Powering 300+ Clients from 20+ Countries With Our Web, App & Digital Solutions</h1>
                     <h6 class="mb-5">Startup - SMB's - Enterprise - Businesses</h6>
                     <button type="button" class="btn_Theme_green btnLg">Let's Discuss Your Project</button>
                  </div>
               </div>
            </div>
         </div>
      </section>