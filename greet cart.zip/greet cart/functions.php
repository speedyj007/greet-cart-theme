<?php


	function load_stylesheets()
	{
		
		wp_register_style("owl", get_template_directory_uri() . '/assets/css/owl.carousel.min.css', array(), 1,'all');
		wp_enqueue_style('owl');	
		
		wp_register_style("styles", get_template_directory_uri()  . '/assets/css/style.css', array(), 1,'all');
		wp_enqueue_style('styles');	
	}



add_action('wp_enqueue_scripts','load_stylesheets');



function addjs()
{
	
	wp_register_script('jquery', get_template_directory_uri() .'/assets/js/jquery.3.3.1.min.js', array(),1,1,1);
	wp_enqueue_script('jquery');
	
	
	wp_enqueue_script('owlcar', get_template_directory_uri() . '/assets/js/owl.carousel.min.js');
	
	
	wp_enqueue_script('custom',get_template_directory_uri() . '/custom.js');
	
}

    add_action('wp_enqueue_scripts', 'addjs');  