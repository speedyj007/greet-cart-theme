<footer class="footer">
         <a href="javascript:void(0);" id="backtotop" class="backtotop"><span class="sprite_ico backtop_ico"></span></a>
         <div class="container py-4">
            <div class="row">
               <div class="col">
                  <img src="<?php bloginfo('template_directory'); ?> /assets/images/footer_logo.png" class="mb-4 footer_logo" alt="" />
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
               </div>
               <div class="col-2 pt-4">
                  <h5>Important Links</h5>
                  <ul class="p-0">
                     <li><a href="javascript:void(0);">Home</a></li>
                     <li><a href="javascript:void(0);">Who We are</a></li>
                     <li><a href="javascript:void(0);">What we do</a></li>
                     <li><a href="javascript:void(0);">Our Work</a></li>
                     <li><a href="javascript:void(0);">Blog</a></li>
                     <li><a href="javascript:void(0);">Contact Us</a></li>
                  </ul>
               </div>
               <div class="col-2 pt-4">
                  <h5>Featured Services</h5>
                  <ul class="p-0">
                     <li><a href="javascript:void(0);">Home</a></li>
                     <li><a href="javascript:void(0);">Who We are</a></li>
                     <li><a href="javascript:void(0);">What we do</a></li>
                     <li><a href="javascript:void(0);">Our Work</a></li>
                     <li><a href="javascript:void(0);">Blog</a></li>
                     <li><a href="javascript:void(0);">Contact Us</a></li>
                  </ul>
               </div>
               <div class="col pt-4">
                  <h5>Contact Us</h5>
                  <p>B-54, Giriraj Industrial Estate, Mahakali Caves Road, Andheri (East), Mumbai � 400093.</p>
                  <p>+91 983 399 1350</p>
                  <p>info@cart-geek.com</p>
               </div>
            </div>
         </div>
         <div class="bg-dark py-3 text-white bottomfooter">
            <div class="container">
               <div class="row">
                  <div class="col-6">
                     <p class="text-white m-0">Copyright � 2020 Cart Geek.|  All right reserved  
                        <a href="javascript:void(0);" class="text-white ml-4 mx-3">Terms</a> 
                        <a href="javascript:void(0);" class="text-white mx-3">Privacy</a>
                        <a href="javascript:void(0);" class="text-white mx-3">Sitemap</a>
                     </p>
                  </div>
                  <div class="col-4 text-center">
                     <a href="javascript:void(0);" class="d-inline-block mr-3">
                     <img src="<?php bloginfo('template_directory'); ?> /assets/images/common-sprite-1.png" class="" alt="" />
                     </a> 
                     <a href="javascript:void(0);" class="d-inline-block ml-3">
                     <img src="<?php bloginfo('template_directory'); ?> /assets/images/dmca-badge-w100-5x1-08.png" class="" alt="" />
                     </a>
                  </div>
                  <div class="col-2 socialIco text-right">
                     <a href="javascript:void(0);" class="d-inline-block"><span class="sprite_ico facebook_ico"></span></a>
                     <a href="javascript:void(0);" class="d-inline-block"><span class="sprite_ico twitter_ico"></span></a>
                     <a href="javascript:void(0);" class="d-inline-block"><span class="sprite_ico linkedin_ico"></span></a>
                     <a href="javascript:void(0);" class="d-inline-block"><span class="sprite_ico instagram_ico"></span></a>
                  </div>
               </div>
            </div>
         </div>
      </footer>
	  
	  
	  <?php wp_footer();?>